<?php /* Template Name: Rsserve Page */ 
get_header(); ?>
  

<?php get_template_part( 'template-parts/tap_question' ); ?>
  
<?php get_template_part( 'template-parts/reserve' ); ?>

<?php get_footer(); ?>
