<?php /* Template Name: Homepage */ 
get_header(); ?>
  
<?php get_template_part( 'template-parts/image_slide' ); ?>

<?php get_template_part( 'template-parts/tap' ); ?>

<?php get_template_part( 'template-parts/tap_question' ); ?>
      
<?php get_template_part( 'template-parts/service_overall' ); ?>
      
<?php get_template_part( 'template-parts/contact' ); ?>

<?php get_footer(); ?>
