<?php
/**
 * The template part for displaying tap
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen_Child
 */
?>

<div id="tap">
	<div class="row">
	  <div class="col-sm-12 col-md-6 col-lg-6 left"></div>
	  <div class="col-sm-12 col-md-6 col-lg-6 right">
	    <h4 class="special">The story of</h4>
	    <h2>Tapped</h2>
	    <div class="line"></div>
	    <p>
	      Tapped Coffee & craft beverages was started because we saw a
	      need for nitro coffee all year round. Once we started we quickly
	      saw a need for a great tasting cold and hot beverages which is
	      why we offer a large selection of beverages.
	    </p>
	  </div>
	</div>
</div>