<?php /* Template Name: Contact Page */ 
get_header(); ?>
  
  
<?php get_template_part( 'template-parts/contact' ); ?>

<?php get_footer(); ?>
